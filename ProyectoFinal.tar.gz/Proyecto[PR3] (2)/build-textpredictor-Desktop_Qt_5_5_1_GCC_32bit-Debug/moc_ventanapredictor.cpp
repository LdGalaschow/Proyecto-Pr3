/****************************************************************************
** Meta object code from reading C++ file 'ventanapredictor.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../textpredictor/ventanapredictor.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ventanapredictor.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ventanapredictor_t {
    QByteArrayData data[40];
    char stringdata0[973];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ventanapredictor_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ventanapredictor_t qt_meta_stringdata_ventanapredictor = {
    {
QT_MOC_LITERAL(0, 0, 16), // "ventanapredictor"
QT_MOC_LITERAL(1, 17, 16), // "predictor_signal"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 5), // "value"
QT_MOC_LITERAL(4, 41, 24), // "on_actionNuevo_triggered"
QT_MOC_LITERAL(5, 66, 24), // "on_actionAbrir_triggered"
QT_MOC_LITERAL(6, 91, 26), // "on_actionGuardar_triggered"
QT_MOC_LITERAL(7, 118, 31), // "on_actionGuardar_Como_triggered"
QT_MOC_LITERAL(8, 150, 25), // "on_actionCopiar_triggered"
QT_MOC_LITERAL(9, 176, 25), // "on_actionCortar_triggered"
QT_MOC_LITERAL(10, 202, 24), // "on_actionPegar_triggered"
QT_MOC_LITERAL(11, 227, 27), // "on_actionDeshacer_triggered"
QT_MOC_LITERAL(12, 255, 26), // "on_actionRehacer_triggered"
QT_MOC_LITERAL(13, 282, 25), // "on_textEditor_textChanged"
QT_MOC_LITERAL(14, 308, 29), // "on_actionTexto_Rojo_triggered"
QT_MOC_LITERAL(15, 338, 29), // "on_actionTexto_Azul_triggered"
QT_MOC_LITERAL(16, 368, 30), // "on_actionTexto_Verde_triggered"
QT_MOC_LITERAL(17, 399, 30), // "on_actionTexto_Negro_triggered"
QT_MOC_LITERAL(18, 430, 27), // "on_actionOblivion_triggered"
QT_MOC_LITERAL(19, 458, 27), // "on_actionDarkBlue_triggered"
QT_MOC_LITERAL(20, 486, 26), // "on_actionRedSkin_triggered"
QT_MOC_LITERAL(21, 513, 26), // "on_actionClasico_triggered"
QT_MOC_LITERAL(22, 540, 31), // "on_actionTexto_Morado_triggered"
QT_MOC_LITERAL(23, 572, 31), // "on_actionBlack_Orange_triggered"
QT_MOC_LITERAL(24, 604, 24), // "on_actionTimes_triggered"
QT_MOC_LITERAL(25, 629, 35), // "on_actionHelvetica_Cronyx_tri..."
QT_MOC_LITERAL(26, 665, 26), // "on_actionCourier_triggered"
QT_MOC_LITERAL(27, 692, 29), // "on_actionOldEnglish_triggered"
QT_MOC_LITERAL(28, 722, 21), // "on_action10_triggered"
QT_MOC_LITERAL(29, 744, 21), // "on_action12_triggered"
QT_MOC_LITERAL(30, 766, 21), // "on_action14_triggered"
QT_MOC_LITERAL(31, 788, 21), // "on_action16_triggered"
QT_MOC_LITERAL(32, 810, 28), // "on_actionRoyalGold_triggered"
QT_MOC_LITERAL(33, 839, 40), // "on_actionPor_Defecto_Monospac..."
QT_MOC_LITERAL(34, 880, 25), // "on_actionBuscar_triggered"
QT_MOC_LITERAL(35, 906, 7), // "signalR"
QT_MOC_LITERAL(36, 914, 4), // "text"
QT_MOC_LITERAL(37, 919, 8), // "signalRA"
QT_MOC_LITERAL(38, 928, 5), // "textA"
QT_MOC_LITERAL(39, 934, 38) // "on_actionMostrar_Diccionario_..."

    },
    "ventanapredictor\0predictor_signal\0\0"
    "value\0on_actionNuevo_triggered\0"
    "on_actionAbrir_triggered\0"
    "on_actionGuardar_triggered\0"
    "on_actionGuardar_Como_triggered\0"
    "on_actionCopiar_triggered\0"
    "on_actionCortar_triggered\0"
    "on_actionPegar_triggered\0"
    "on_actionDeshacer_triggered\0"
    "on_actionRehacer_triggered\0"
    "on_textEditor_textChanged\0"
    "on_actionTexto_Rojo_triggered\0"
    "on_actionTexto_Azul_triggered\0"
    "on_actionTexto_Verde_triggered\0"
    "on_actionTexto_Negro_triggered\0"
    "on_actionOblivion_triggered\0"
    "on_actionDarkBlue_triggered\0"
    "on_actionRedSkin_triggered\0"
    "on_actionClasico_triggered\0"
    "on_actionTexto_Morado_triggered\0"
    "on_actionBlack_Orange_triggered\0"
    "on_actionTimes_triggered\0"
    "on_actionHelvetica_Cronyx_triggered\0"
    "on_actionCourier_triggered\0"
    "on_actionOldEnglish_triggered\0"
    "on_action10_triggered\0on_action12_triggered\0"
    "on_action14_triggered\0on_action16_triggered\0"
    "on_actionRoyalGold_triggered\0"
    "on_actionPor_Defecto_Monospace_triggered\0"
    "on_actionBuscar_triggered\0signalR\0"
    "text\0signalRA\0textA\0"
    "on_actionMostrar_Diccionario_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ventanapredictor[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  189,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  192,    2, 0x08 /* Private */,
       5,    0,  193,    2, 0x08 /* Private */,
       6,    0,  194,    2, 0x08 /* Private */,
       7,    0,  195,    2, 0x08 /* Private */,
       8,    0,  196,    2, 0x08 /* Private */,
       9,    0,  197,    2, 0x08 /* Private */,
      10,    0,  198,    2, 0x08 /* Private */,
      11,    0,  199,    2, 0x08 /* Private */,
      12,    0,  200,    2, 0x08 /* Private */,
      13,    0,  201,    2, 0x08 /* Private */,
      14,    0,  202,    2, 0x08 /* Private */,
      15,    0,  203,    2, 0x08 /* Private */,
      16,    0,  204,    2, 0x08 /* Private */,
      17,    0,  205,    2, 0x08 /* Private */,
      18,    0,  206,    2, 0x08 /* Private */,
      19,    0,  207,    2, 0x08 /* Private */,
      20,    0,  208,    2, 0x08 /* Private */,
      21,    0,  209,    2, 0x08 /* Private */,
      22,    0,  210,    2, 0x08 /* Private */,
      23,    0,  211,    2, 0x08 /* Private */,
      24,    0,  212,    2, 0x08 /* Private */,
      25,    0,  213,    2, 0x08 /* Private */,
      26,    0,  214,    2, 0x08 /* Private */,
      27,    0,  215,    2, 0x08 /* Private */,
      28,    0,  216,    2, 0x08 /* Private */,
      29,    0,  217,    2, 0x08 /* Private */,
      30,    0,  218,    2, 0x08 /* Private */,
      31,    0,  219,    2, 0x08 /* Private */,
      32,    0,  220,    2, 0x08 /* Private */,
      33,    0,  221,    2, 0x08 /* Private */,
      34,    0,  222,    2, 0x08 /* Private */,
      35,    1,  223,    2, 0x08 /* Private */,
      37,    1,  226,    2, 0x08 /* Private */,
      39,    0,  229,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void, QMetaType::QString,   38,
    QMetaType::Void,

       0        // eod
};

void ventanapredictor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ventanapredictor *_t = static_cast<ventanapredictor *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->predictor_signal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->on_actionNuevo_triggered(); break;
        case 2: _t->on_actionAbrir_triggered(); break;
        case 3: _t->on_actionGuardar_triggered(); break;
        case 4: _t->on_actionGuardar_Como_triggered(); break;
        case 5: _t->on_actionCopiar_triggered(); break;
        case 6: _t->on_actionCortar_triggered(); break;
        case 7: _t->on_actionPegar_triggered(); break;
        case 8: _t->on_actionDeshacer_triggered(); break;
        case 9: _t->on_actionRehacer_triggered(); break;
        case 10: _t->on_textEditor_textChanged(); break;
        case 11: _t->on_actionTexto_Rojo_triggered(); break;
        case 12: _t->on_actionTexto_Azul_triggered(); break;
        case 13: _t->on_actionTexto_Verde_triggered(); break;
        case 14: _t->on_actionTexto_Negro_triggered(); break;
        case 15: _t->on_actionOblivion_triggered(); break;
        case 16: _t->on_actionDarkBlue_triggered(); break;
        case 17: _t->on_actionRedSkin_triggered(); break;
        case 18: _t->on_actionClasico_triggered(); break;
        case 19: _t->on_actionTexto_Morado_triggered(); break;
        case 20: _t->on_actionBlack_Orange_triggered(); break;
        case 21: _t->on_actionTimes_triggered(); break;
        case 22: _t->on_actionHelvetica_Cronyx_triggered(); break;
        case 23: _t->on_actionCourier_triggered(); break;
        case 24: _t->on_actionOldEnglish_triggered(); break;
        case 25: _t->on_action10_triggered(); break;
        case 26: _t->on_action12_triggered(); break;
        case 27: _t->on_action14_triggered(); break;
        case 28: _t->on_action16_triggered(); break;
        case 29: _t->on_actionRoyalGold_triggered(); break;
        case 30: _t->on_actionPor_Defecto_Monospace_triggered(); break;
        case 31: _t->on_actionBuscar_triggered(); break;
        case 32: _t->signalR((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 33: _t->signalRA((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 34: _t->on_actionMostrar_Diccionario_triggered(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ventanapredictor::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ventanapredictor::predictor_signal)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject ventanapredictor::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_ventanapredictor.data,
      qt_meta_data_ventanapredictor,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ventanapredictor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ventanapredictor::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ventanapredictor.stringdata0))
        return static_cast<void*>(const_cast< ventanapredictor*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int ventanapredictor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 35)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 35;
    }
    return _id;
}

// SIGNAL 0
void ventanapredictor::predictor_signal(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
